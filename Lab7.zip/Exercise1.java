
/**
 * November 6th, 2017 11:21 AM
 * @author hmann11
 * This program encrypts a given string with a ceasar cipher using a randomly generated shift. 
 * Then the program prints out the encrypted string and repeatedly asks the user to guess the value of shift.
 * If the shift value entered is right the program stops, but if it is not then the program uses this value 
 * of shift to decrypt the string and print it out.
 */
import java.util.Scanner;

public class Exercise1 {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.println("Please enter a phrase to encrypt:");
		String str = input.nextLine();
		int shift = (int) (Math.random() * (26 - (-26) + 1) + (-26));// generating a random integer between the range of
																		// -26 and 26.
		String encrypted = "";// Empty string to save the result of the encryption.
		// Setting up a for loop so that every char in the entered string can be
		// encrypted using the shift value provided.
		for (int i = 0; i < str.length(); i++) {
			char ch = str.charAt(i);
			if (shift > 0)
				encrypted += (rightShiftCharacter(ch, shift));// right shift for positive amount of shift.
			else
				encrypted += (leftShiftCharacter(ch, shift));// left shift for negative amount of shift.
		}
		System.out.println("Your encrypted phrase is :" + encrypted);

		System.out.println("Enter your guess to decypt the phrase(-26 to 26)");
		boolean correctAnswer = false;
		int choice = input.nextInt();
		// While loop to repeatedly ask the user for an input until the correct amount
		// of shift is provided by the user.
		while (correctAnswer == false) {
			if (choice == shift) {
				System.out.println("Correct! Your phrase was encrypted using a shift of: " + shift);
				correctAnswer = true;
			} else
				System.out.println(
						"That's not the exact right number, although it decrypts to: " + decrypt(encrypted, choice));
			choice = input.nextInt();
		}
		input.close();
	}

	/**
	 * Creating a encrypted character using the original character and shift
	 * provided by adding shift to the number ascii value of the char and moving
	 * 'left' of the range.
	 * 
	 * @param ch is unecrypted char.
	 * @param shift is amount by which the ch is to be shifted to the left.
	 * @return encrypted char
	 */
	public static char rightShiftCharacter(char ch, int shift) {
		// Using if else statements to sort every char into its appropriate range.
		if (ch >= 'a' && ch <= 'z') {
			// ((ch-lowerlimit+shift)%26) provides with number which when added to
			// the lowerlimit of the range gives us the encrypted
			// character.
			ch = (char) ('a' + (ch - 'a' + shift) % 26);
		} else if (ch >= 'A' && ch <= 'Z') {
			ch = (char) ('A' + (ch - 'A' + shift) % 26);
		} else if (ch >= '0' && ch <= '9') {
			ch = (char) ('0' + (ch - '0' + shift) % 10);
		}

		return ch;
	}

	/**
	 * Creating a encrypted character using the original character and shift
	 * provided by adding the negative shift to the number ascii value of the char
	 * and moving 'right' of the range.
	 * 
	 * @param ch is the unencrypted char.
	 * @param shift is amount by which the ch is to be shifted to the right.
	 * @return encrypted character
	 */
	public static char leftShiftCharacter(char ch, int shift) {

		if (ch >= 'a' && ch <= 'z') {
			// ((ch-upperlimit+shift)%26) provides the negative number that when subtracted
			// from the upperlimit of the range provides the encrypted character.
			ch = (char) ('z' + (ch - 'z' + shift) % 26);
		} else if (ch >= 'A' && ch <= 'Z') {
			ch = (char) ('Z' + (ch - 'Z' + shift) % 26);
		} else if (ch >= '0' && ch <= '9') {
			ch = (char) ('9' + (ch - '9' + shift) % 10);
		}

		return ch;
	}

	/**
	 * A program that takes in a encrypted ciphertext and the shift used to encrypt
	 * the original text and returns a decrypted string.
	 * 
	 * @param ciphertext is the encrypted text which needs to be decrypted.
	 * @param shift is the key used to encrypt the original text in the first place.
	 * @return decrypted string which would identical to the original unencrypted
	 *         string.
	 */
	public static String decrypt(String ciphertext, int shift) {
		String decrypted = "";
		shift = -shift;
		// Reversing cipher method to decrypt i.e. if a cipher text is encrypted using
		// right character shift it can be decryted using the negative value of the
		// original shift and using this value with the left character shift method and
		// vice-versa.
		for (int i = 0; i < ciphertext.length(); i++) {
			char ch = ciphertext.charAt(i);
			if (shift > 0)
				decrypted += (rightShiftCharacter(ch, shift));
			else
				decrypted += (leftShiftCharacter(ch, shift));
		}
		return decrypted;

	}

}
