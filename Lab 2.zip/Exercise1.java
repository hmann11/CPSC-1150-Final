
/**
 * September 20, 2017 2:08 PM
 * @author hmann11
 * This program converts a given integer amount of minutes to the corresponding number of years and days.
 */
import java.util.Scanner;

public class Exercise1 {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);// initializing new Scanner called input.
		System.out.println("Please enter the amount of time to be converted in minutes and then press Enter.");
		int min = input.nextInt();// Waiting for a input from the user.
		int day = min % 525600 / 60 / 24;// modulus of the given number and number of minutes in a year i.e. the
											// remainder divided by the seconds in a day to get just the number of days
											// and storing in variable day.
		int year = min / 60 / 24 / 365;// Dividing the given number by the number of minutes in a year and storing the
										// quotient in variable year.
		System.out.println(min + " minutes is about " + year + " years and " + day + " days");
		input.close();

	}

}
