
/**
 * September 22nd, 2017 3:08 PM
 * @author CPSC 1150 teachers and hmann11
 * This program converts a 4 digit base 10 number to another base between 2 to 9.
 */
// ************************************************
//   BaseConvert.java
//   Converts base 10 numbers to another base
//   (at most 4 digits in the other base).  The
//   base 10 number and the base are input.
// ************************************************

import java.util.Scanner;

public class Exercise3 {
	public static void main(String[] args) {
		int base; // the new base
		int base10Num; // the number in base 10
		int maxNumber; // the maximum number that will fit
						// in 4 digits in the new base

		int place0; // digit in the 1's (base^0) place
		int place1; // digit in the base^1 place
		int place2; // digit in the base^2 place
		int place3; // digit in the base^3 place
		int quotient; // quotient when dividing by the base

		Scanner scan = new Scanner(System.in);

		String baseBNum = new String(""); // the number in the new base

		// read in the base 10 number and the base
		System.out.println();
		System.out.println("Base Conversion Program");
		System.out.println();
		System.out.print("Please enter a base (2 - 9): ");
		System.out.println();
		base = scan.nextInt();
		maxNumber = (int) Math.pow(base, 4) - 1;// Equation to compute the possible number of 4 digit outcomes
												// for a specific base.

		// 1. Compute the maximum base 10 (maxNumber) number that will fit
		// in 4 digits in the new base and tell the user what range the number
		// they want to convert must be in. Then add a statement that prints out
		// the result (appropriately labeled).

		System.out.print("Please enter a base 10 number in the range 0 to " + maxNumber + " to convert: ");
		System.out.println();
		base10Num = scan.nextInt();// Waiting for user input.
		scan.close();
		place0 = (base10Num % base);// Remainder of number entered by the user and the desired base saved in
									// place0.
		quotient = base10Num / base;// Saving the quotient of the number and desired base into variable quotient.
		place1 = (quotient % base);// Remainder of quotient and desired base saved in place1.
		quotient = (quotient / base);// Quotient revised for the second division.
		place2 = (quotient % base);// Remainder of revised quotient divided by the base and stored in place2.
		quotient = (quotient / base);// Quotient revised for third division.
		place3 = (quotient % base);// Final division to calculate the last digit and save it in place3
		// As we divide the given number by the desired base, the remainder of the
		// division takes a place in the new base starting from right to left and the
		// quotient becomes the dividend for the next division,the divider remains
		// constant. This process repeats 4 times, which is one for each digit of
		// the new number.
		baseBNum = "" + place3 + place2 + place1 + place0;// Concatenating the places and saving the resulting
															// number as a string.
		System.out.println(base10Num + " in base " + base + " is equal to " + baseBNum + ".");// Printing out 
		// the string with the resulting number.
	}
}
