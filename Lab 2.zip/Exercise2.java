
/**
 * September 20, 2017 3:07 PM
 * @author hmann11
 * This program takes 2 integers, raises them to the power of 3 and then adds the result. 
 */
import java.util.Scanner;

public class Exercise2 {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);// Initializing new Scanner called input.
		System.out.println("Please enter the first integer");
		int x = input.nextInt();// Waiting for user to input a integer.
		System.out.println("Please enter the second integer");
		int y = input.nextInt();// Waiting for user to input a integer.
		input.close();
		int result;
		result = (int) Math.pow(x, 3) + (int) Math.pow(y, 3);// x is raised to power 3 and y is raised to power 3, and
																// then the two variables are added to get the result.
		System.out.println("(" + x + "^3)+" + " (" + y + "^3) = " + result);

	}

}
