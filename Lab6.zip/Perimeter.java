
/**
 * October 30th, 2017 1:08 AM
 * @author jmckeescott, hmann11
 * A class that allows the user to input three points from a triangle
 * or the radius of the circle, and determines the perimeter of the shape
 */
import java.text.DecimalFormat;
import java.util.Scanner;

public class Perimeter {

	public static void main(String[] args) {

		Scanner input = new Scanner(System.in);
		displayMenu();// Calling method to print out user choices.
		int userChoice = input.nextInt();
		// Using a while loop to ask the user for a input repeatedly and exit the loop
		// when required.
		while (userChoice != 3) {
			// Using switch to call the right method for the option selected by the user.
			switch (userChoice) {
			case 1:
				TrianglePerimeter();
				break;
			case 2:
				System.out.print("Please enter a radius: ");
				int r = input.nextInt();
				while (inputCheck(r) != true) {// Checking r to make sure it's a positive number and asking for the
												// right input in case the radius entered is not positive.
					r = input.nextInt();
				}
				System.out.println("The perimeter of a circle with radius " + r + " is " + CircumF(r) + "\n");
				break;

			default:
				System.out.println("Please enter a valid choice.");
				break;
			}
			// Completing the loop by asking the user to choose a option again.
			displayMenu();
			userChoice = input.nextInt();

		}
		input.close();
	}

	/**
	 * A method that prints out the choices for the user to select from.
	 */
	public static void displayMenu() {

		System.out.println("Select one of the following options:");
		System.out.println(" 1. Triangle");
		System.out.println(" 2. Circle");
		System.out.println(" 3. Exit");

	}

	/**
	 * A method that takes in 6 variables and treats them like points on a Cartesian
	 * plane to calculate the perimeter of the triangle. If the points are collinear
	 * the method will state that and print out the length of the line they form.
	 */
	public static void TrianglePerimeter() {

		DecimalFormat formatter = new DecimalFormat("#0.000000");// Setting up a formatter to format the result.
		Scanner input = new Scanner(System.in);
		// Using while loops to keep asking the user for a positive integer until they
		// provide one.
		System.out.print("Please enter X1:");
		int x1 = input.nextInt();
		while (inputCheck(x1) != true) {
			x1 = input.nextInt();
		}
		System.out.print("Please enter Y1:");
		int y1 = input.nextInt();
		while (inputCheck(y1) != true) {
			y1 = input.nextInt();
		}
		System.out.print("Please enter X2:");
		int x2 = input.nextInt();
		while (inputCheck(x2) != true) {
			x2 = input.nextInt();
		}
		System.out.print("Please enter Y2:");
		int y2 = input.nextInt();
		while (inputCheck(y2) != true) {
			y2 = input.nextInt();
		}
		System.out.print("Please enter X3:");
		int x3 = input.nextInt();
		while (inputCheck(x3) != true) {
			x3 = input.nextInt();
		}
		System.out.print("Please enter Y3:");
		int y3 = input.nextInt();
		while (inputCheck(y3) != true) {
			y3 = input.nextInt();
		}
		// Calling method dist to perform distance addition for 2 points to calculate
		// the length of each of side of a triangle.
		double s1 = dist(x1, y1, x2, y2);
		double s2 = dist(x2, y2, x3, y3);
		double s3 = dist(x3, y3, x1, y1);
		// Adding the 3 calculated sides to find the perimeter of the triangle.
		double perimeter = s1 + s2 + s3;
		// Setting up a if-else statement to check if the points are collinear. If the
		// lines are collinear then the program prints out the lenght of the line the 3
		// points form.
		if (Collinear(x1, y1, x2, y2, x3, y3) == true) {
			System.out.println("The points provided actually form a line and not a triangle of the lenght: "
					+ formatter.format(perimeter) + "\n");
		} else
			System.out.println("The perimeter of a triangle with points(" + x1 + "," + y1 + ") and (" + x2 + "," + y2
					+ ") and (" + x3 + "," + y3 + ") is " + formatter.format(perimeter) + "\n");
	}

	/**
	 * Performs distance addition on 2 provided points.
	 * 
	 * @return result to the TrianglePerimeter method
	 */
	public static double dist(double x1, double y1, double x2, double y2) {
		// Performing the mathematical equation: sqrt[(x1-x2)^2+(y1-y2)^2] to find the
		// distance between the 2 points provided.
		double result = Math.sqrt(Math.pow((x1 - x2), 2) + Math.pow((y1 - y2), 2));
		return result;
	}

	/**
	 * This method takes in a variable which is used as a radius to calculate the
	 * circumference of a circle.
	 * 
	 * @return the appropriately formatted circumference is returned to the method
	 *         that called this function.
	 */
	public static String CircumF(float i) {
		// Performing the mathematical equation: 2*Pi*radius(i) and calculating the
		// circumference.
		DecimalFormat formatter = new DecimalFormat("#0.00");
		double result = (2 * Math.PI * i);
		return formatter.format(result);
	}

	/**
	 * A method that checks if the user input is in the correct format.
	 * 
	 * @return a boolean false and asks the user to enter a valid input.
	 */
	public static boolean inputCheck(double userInput) {
		// Printing out a response asking the user for a valid input if the input
		// entered is not appropriate for the method calling inputCheck.
		if (userInput < 0) {
			System.out.println("Please enter a valid input.");
			return false;
		} else
			return true;
	}

	/**
	 * This method takes the points provided in the TrianglePerimeter method and
	 * checks if the points are collinear i.e. if they form a line and not a
	 * triangle.
	 * 
	 * @return A boolean true if it is collinear and returns false if the points are
	 *         not collinear.
	 */
	public static boolean Collinear(double x1, double y1, double x2, double y2, double x3, double y3) {
		// Rearranging the formula [(x2-x1)/(x3-x1)]=[(y2-y1)/(y3-y1)] to get the
		// formula [(x2-x1)(y3-y1)]-[(x3-x1)(y2-y1)]=0. If the rearranged equation is
		// equal to 0 then the points are actually collinear, but if not then the points
		// actually form a triangle.
		double result = ((x2 - x1) * (y3 - y1)) - ((x3 - x1) * (y2 - y1));
		if (result == 0) {
			return true;
		} else
			return false;
	}
}