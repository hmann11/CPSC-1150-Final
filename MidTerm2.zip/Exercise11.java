
public class Exercise11 {
	public static void main(String[]args) {
		int[] arr = { 4, 8, 6, 1, 2, 9, 4 };
		System.out.println(smallestNeighbour(arr));
	}

	public static int smallestNeighbour(int[]arr ) {
		
		int abs = arr[1] - arr[2];
		int absIndex = 0;
		int diff = 0;
		for (int i = 0; i < arr.length - 1; i++) {
			diff = arr[i] - arr[i + 1];
			System.out.println(diff);
			if (diff > abs) {
				abs=Math.abs(diff);
				absIndex = i;
			}

		}
		return absIndex;
	}

}
