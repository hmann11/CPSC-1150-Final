import java.util.Arrays;
import java.util.Scanner;

public class Exercise10 {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.println("Please enter the 2 strings");
		String str1 = input.nextLine().toLowerCase();
		String str2 = input.nextLine().toLowerCase();
		System.out.println(anagram(str1, str2));
	}

	public static String anagram(String str1, String str2) {

		boolean[] solid = new boolean[str1.length()];

		for (int i = 0; i < str1.length(); i++) {

			for (int j = 0; j < str2.length(); j++) {

				if (str1.charAt(i) == str2.charAt(j)) {
					solid[i] = true;
				} else {
					solid[i] = false;

				}

			}

		}
		return Arrays.toString(solid);
	}
}