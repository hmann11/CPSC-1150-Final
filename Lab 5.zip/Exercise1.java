
/**
 * October 23rd, 2017 11:17 AM
 * @author hmann11
 * This program takes in a string of characters and prints the number of vowels and consonants present in that string.
 */
import java.util.Scanner;

public class Exercise1 {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.print("Please enter an Alphabet:");
		String str = input.nextLine();
		input.close();
		// Initializing ints to record the number of individual vowels and consonants.
		int non_vowel = 0;
		int a, e, i, o, u;
		a = e = i = o = u = 0;
		int A, E, I, O, U;
		A = E = I = O = U = 0;
		// Setting up a for loop in order to check every character in the given string
		// amongst the following statements. The int J acts as a pointer which moves one
		// slot every time the entire block of code is executed.
		for (int j = 0; j < str.length(); j++) {
			//Storing the character at the present location of the "pointer"  in the char 'letter'.
			char letter = str.charAt(j);
			if (letter == 'a') {
				a++;
			} else {
				if (letter == 'A') {
					A++;
				} else {
					if (letter == 'e') {
						e++;
					} else {
						if (letter == 'E') {
							E++;
						} else {
							if (letter == 'i') {
								i++;
							} else {
								if (letter == 'I') {
									I++;
								} else {
									if (letter == 'o') {
										o++;
									} else {
										if (letter == 'O') {
											O++;
										} else {
											if (letter == 'u') {
												u++;
											} else {
												if (letter == 'U') {
													U++;
												} else
													non_vowel++;
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
		a += A;
		e += E;
		i += I;
		o += O;
		u += U;
		System.out.println("a: " + a + "\n" + "e: " + e + "\n" + "i: " + i + "\n" + "o: " + o + "\n" + "u: " + u + "\n"
				+ "non-vowels:" + non_vowel);
	}
}