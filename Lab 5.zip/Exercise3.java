
/**
 * October 21st, 2017 4:34 AM
 * @author hmann11
 * This program takes in a odd integer and prints out a cross made of stars.
 */
import java.util.Scanner;

public class Exercise3 {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.print("Please enter an odd number of stars: ");
		int stars = input.nextInt();
		// If statement to check if the number entered is odd.
		if (stars % 2 != 0) {
			// Setting up two for loops to act as a cursor and then checking the location of
			// the cursor using an if statement and printing out a '*' if required.
			for (int row = 0; row < stars; row++) {
				for (int col = 0; col < stars; col++) {
					// Using the if statement to print out a * only when the col and row variables
					// are equal or when the two variables are at the opposite end of the range
					// provided by the star variable.
					if (row == col || row + col == stars - 1) {
						System.out.print("*");
					} else {
						System.out.print(" ");
					}
				}
				System.out.println();
			}
		} else {
			System.out.println("Please enter an odd number.");
		}
		input.close();
	}

}
