
/**
 * October 21st, 2017 8:47 PM
 * @author hmann11
 * This program acts as a bank account and takes in a amount of money and calculates
 * how long it will last if $500 is taken out of the account every month. 
 */
import java.util.Scanner;

public class Exercise2 {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.print("Please enter a account balance: ");
		int bal = input.nextInt();
		int i = 1;
		// Setting up a do while loop to emulate the monthly interest and deductions of
		// the bank account.
		do {
			i++;
			bal += bal * (0.5 / 100);
			bal -= 500;
		} while (bal >= 500 && i < 10000);
		// Nested if-else loops to determine what kind of output is required depending
		// on how long it would take the account to deplete.
		if (i >= 10000)
			System.out.println("The account will not deplete.");
		else {
			int year = i / 12;
			int month = i % 12;
			if (year == 0 && month == 1) {
				System.out.println(month + " month");
			} else {
				if (year == 0 && month > 1) {
					System.out.println(month + " months");
				} else {
					if (year > 1 && month == 0) {
						System.out.println(year + " years");
					} else {
						if (year == 1 && month == 1) {
							System.out.println(year + " year and " + month + " month");
						} else {
							if (year == 1 && month > 1) {
								System.out.println(year + " year and " + month + " months");
							} else {
								System.out.println(year + " years and " + month + " months");
							}
						}
					}
				}
			}
		}
		input.close();
	}
}
