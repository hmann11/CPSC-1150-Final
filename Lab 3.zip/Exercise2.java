
/**
 * October 1, 2017 12:15 PM
 * @author hmann11
 * This program adds a "izzle" at the end of every word in a string and makes Calvin Cordozar Broadus Jr. aka Snoop Dogg proud. 
 */
import java.util.Scanner;

public class Exercise2 {

	public static void main(String[] args) {
		// Creating a new Scanner called 'input'.
		Scanner input = new Scanner(System.in);
		System.out.println("Please enter a string of words.");
		String str = input.nextLine();
		// I'm using the trim method just in case the user leaves an extra space before
		// or after the string.
		str = str.trim();
		input.close();
		// Leaving a space after the "izzle" to compensate for the loss of space in the
		// replace method.
		String str1 = "izzle ";
		// Replacing all the spaces in the string with the string "izzle ".
		String str2 = str.replace(" ", str1);
		//Adding a "izzle" at the end of the new string.   
		System.out.println(str2 + "izzle");
	}

}
