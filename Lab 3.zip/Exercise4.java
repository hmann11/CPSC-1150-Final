
/**
 * October 1,2017 12:37 PM
 * @author hmann11
 * This program takes the first and last name of a user and generates a random 2 digit number in order to create a random username. 
 */
import java.util.Scanner;
import java.util.Random;

public class Exercise4 {

	public static void main(String[] args) {
		// Creating a Scanner called 'input' and a random number generator called 'gen'.
		Scanner input = new Scanner(System.in);
		Random gen = new Random();
		// Asking for the user's first and last name and changing the both the inputs to
		// Upper case.
		System.out.println("PLease enter your first name:");
		String first = input.nextLine().toUpperCase();
		System.out.println("Please enter your last name:");
		String last = input.nextLine().toUpperCase();
		input.close();
		// Creating two characters s1 and s2, and saving the first letter of the first
		// and last name in them respectively.
		char s1 = first.charAt(0);
		char s2 = last.charAt(0);
		// Taking the 5 letter subsequent to the first letter of the last name,
		// converting it to the Lower case and then finally storing the result in Sting
		// s3.
		String s3 = last.substring(1, 5).toLowerCase();
		// Generating a random 2 digit number between 10 and 99. 
		int r1 = gen.nextInt(99)+10;
		// Printing the concatenated string.
		System.out.print("" + s1 + s2 + s3 + r1);

	}

}
