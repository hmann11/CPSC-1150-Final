
/**
 * October 1, 2017 12:30 PM
 * @author hmann11
 * This program generates random phone numbers and prints them out in the accepted format. 
 */
import java.util.Random;

public class Exercise3 {

	public static void main(String[] args) {
		// Creating a random number generator called 'gen'.
		Random gen = new Random();
		// Setting a limit on the Math random number generator method since the first 3
		// numbers can't be be 8 or 9.
		int r1 = (int) (Math.random() * 8);
		int r2 = (int) (Math.random() * 8);
		int r3 = (int) (Math.random() * 8);
		// Generating the next 3 digits together using the generator 'gen',setting a
		// limit <=655.
		int r4 = gen.nextInt(555) + 100;
		// Generating the last set of digits using the generator 'gen',setting a limit
		// <=9999 because this set of numbers can be any 4 digit number.
		int r5 = gen.nextInt(8999) + 1000;
		// Adding the appropriate dashes and printing out the concatenated result. 
		System.out.print("" + r1 + r2 + r3 + "-");
		System.out.print(r4 + "-");
		System.out.println(r5);
	}

}
