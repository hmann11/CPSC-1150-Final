
/**
 * October 1, 2017 12:00 PM
 * @author hmann11
 * This program asks for a integer and the converts it into a Char and checks if it satisfies certain condtions.
 */
import java.util.Scanner;

public class Exercise1 {

	public static void main(String[] args) {
		// Creating new scanner called 'input'.
		Scanner input = new Scanner(System.in);
		System.out.println("Please enter an integer between 0 and 256.");
		// Waiting for user input.
		int num = input.nextInt();
		input.close();
		// Converting int num into a char and saving it into ch in order to check if it
		// satisfies the conditions.
		char ch = (char) num;
		// Checking if ch is a character and printing
		// out the result.
		System.out.println(ch + " is a letter: " + Character.isLetter(ch));
		// Checking if ch is upper case
		// and printing out the result.
		System.out.println(ch + " is a Uppercase letter :" + Character.isUpperCase(ch));
		// Checking if ch is lower case
		// and printing out the result.
		System.out.println(ch + " is a Lowecase letter :" + Character.isLowerCase(ch));
		// Checking if ch is a digit and printing out
		// the result.
		System.out.println(ch + " is a number :" + Character.isDigit(ch));
	}

}
