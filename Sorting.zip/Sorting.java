
import java.io.*;
import java.util.Arrays;
import java.util.Scanner;

/**
 * November 27th,2017 12:07PM
 * 
 * @author hmann11 This program takes a text file named releasedates.txt and
 *         sorts it in the ascending order by month or name and then prints the
 *         out to a 2 files named SortedByDate.txt and SortedByName.txt
 *         respectively.
 */
public class Sorting {
	/**
	 * Main method to call all other methods.
	 * 
	 * @param args
	 * @throws FileNotFoundException
	 *             if file not found
	 */
	public static void main(String[] args) throws FileNotFoundException {
		String[] dates = input("releasedates.txt");
		sortByMonth(dates);
		output("SortByMonth.txt", dates);
		sortByName(dates);
		output("SortByNames.txt", dates);
	}

	/**
	 * This method takes in a String called fileName and then looks for a file with
	 * the matching name in the home directory of the program. If the program finds
	 * the matching file it takes the contents of the file and store then in a array
	 * where each line of the file gets a slot in the array.
	 * 
	 * @param fileName
	 * @return
	 * @throws FileNotFoundException
	 *             if file not found
	 */
	public static String[] input(String fileName) throws FileNotFoundException {

		Scanner input = new Scanner(new File(fileName));// initializing scanner to take input from the file with the
														// name fileName.

		int linecount = 0;// Counter to figure out the size of the array needed.
		while (input.hasNextLine()) {
			input.nextLine();
			linecount++;

		}

		input.close();
		input = new Scanner(new File(fileName));
		String[] dates = new String[linecount];// New array of length linecount.
		// Setting up for loop to fill the new array with contents of the file line
		// after line.
		for (int i = 0; i < linecount; i++) {
			dates[i] = input.nextLine();
		}

		input.close();
		return dates;

	}

	/**
	 * This method takes a string and a fileName and then writes a text file
	 * containing the provided array to the home directory of the program. Each slot
	 * of the array is printed out as a individual line.
	 * 
	 * @param fileName
	 * @param info
	 *            is the String array which gets converted to a file.
	 * @throws FileNotFoundException
	 *             if file not found
	 */
	public static void output(String fileName, String[] info) throws FileNotFoundException {
		PrintWriter output = new PrintWriter(new File(fileName));// initializing PrintWriter to output the result in a
																	// text file with the name fileName.
		// for loop to fill in the new file with contents from the sorted array provided
		// to the method. 
		for (int i = 0; i < info.length; i++) {
			output.println(info[i]);
		}
		output.close();
	}

	/**
	 * This method accepts a unsorted array and sorts it in an ascending order.
	 * 
	 * @param array
	 */
	public static void sortByMonth(String[] array) {
		bubbleSort(array, 1);// 1 is the location of the char which is going to be used for comparison.
	}

	/**
	 * This method accepts a unsorted array and sorts it in an ascending order.
	 * 
	 * @param array
	 */
	public static void sortByName(String[] array) {
		bubbleSort(array, 9);// 9 is the location of the char which is going to be used for comparison.
	}

	/**
	 * This method uses bubble sort to sort the given array of data.
	 * 
	 * @param unsorted
	 * @param a
	 * @return
	 */
	public static String[] bubbleSort(String[] unsorted, int a) {
		// boolean to check if another pass is required on the array.
		boolean passReq = true;

		for (int k = 1; k < unsorted.length && passReq; k++) {
			
			passReq = false;
			for (int i = 0; i < unsorted.length - k; i++) {
				if (unsorted[i].charAt(a) > unsorted[i + 1].charAt(a)) {

					String temp = unsorted[i];
					unsorted[i] = unsorted[i + 1];
					unsorted[i + 1] = temp;

					passReq = true;
				}
			}
		}
		return unsorted;
	}

}