/**
 * September 11, 2017 2:50 PM 
 * @author hmann11  
 * This program prints out a line of text and adds 2 initialized integers
 */
public class Exercise1 {
	public static void main(String[] args) {
		// declaring main function
		int a = 6;// initializing the first number i.e. 6
		int b = 5;// initializing the second number i.e. 5
		System.out.println("Hello from ABC in CPSC 1150");// printing text
		System.out.println("6 + 5 =" + (a + b));// printing and then adding two
												// initialized integers
	}

}
