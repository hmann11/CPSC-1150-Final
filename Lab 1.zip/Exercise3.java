/**
 * September 11, 2017 4:15 PM
 * 
 * @author hmann11 This program presents the marks of 3 students in a tabular
 *         form.
 */
public class Exercise3 {

	public static void main(String[] args) {
		String a = "//////////////////";// Initialize backward slashes
		String b = "\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\";// Initialize forward slashes
		System.out.println(a + b);// Printing slashed using string a and b
		System.out.println("==\t  Student  Points\t  ==");
		System.out.println(b + a);
		System.out.println("Name        Lab     Bonus     Total");
		System.out.println("----\t    ---\t    -----     -----");
		System.out.println("Jon\t    55\t     22 \t" + (55 + 22));// Printing Names and Marks line by line and adding
																	// the bonus and lab marks
		System.out.println("Winchester  15\t     66\t\t" + (15 + 66));
		System.out.println("Dany\t    92\t     3\t\t" + (92 + 3));

	}
}
