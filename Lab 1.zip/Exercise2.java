/**
 * September 11, 2017 3:10 PM
 * 
 * @author hmann11 This program spells out my initials using miniature letters
 *         of my initials
 */
public class Exercise2 {

	public static void main(String[] args) {
		System.out.println("H   H  SSSS  M     M");
		System.out.println("H   H  S     M M M M");
		System.out.println("HHHHH  SSSS  M  M  M");
		System.out.println("H   H     S  M     M");
		System.out.println("H   H  SSSS  M     M");
	}

}
