
/**
 * September 11, 2017 10:54 PM
 * @author hmann11
 * This program converts temperature from Celsius scale to Fahrenheit scale. 
 */
import java.util.Scanner;

public class Exercise4 {
	public static void main(String[] args) {
		double ces = 0;// ces is going to store the Celsius scale value
		double fah = 0;// fah is going to store the Fahrenheit scale value
		Scanner input = new Scanner(System.in);// making a new Scanner called input
		System.out.println("Please enter a value in the Celsius scale");// Asking for a input from the user
		ces = input.nextDouble();// Expecting input from user and storing it in the form of a Double
		input.close();// Closing Scanner
		fah = (9.0 / 5) * ces + 32;// Converting celsius to fahrenheit and storing the value in fah variable
		System.out.print("The temperature in Fahrenheit scale is " + fah + "�");
	}
}
