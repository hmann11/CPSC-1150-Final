
/**
 * October 15,2017 12:15 PM
 * @author hmann11
 * This program calculates the real roots of a quadratic equation.
 */
import java.text.DecimalFormat;
import java.util.Scanner;

public class Exercise1 {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		DecimalFormat killdecimal = new DecimalFormat();
		System.out.print("Please enter a, b and c (press space or enter after entering every variable):");
		double a = input.nextDouble();
		double b = input.nextDouble();
		double c = input.nextDouble();
		// x and x2 store the 2 real root values where applicable. If there is only one
		// true root then x is used to store it.
		double x, x2;
		//Raising b to the power of 2 beforehand in order to make the equation simpler.
		double b2 = Math.pow(b, 2);
		input.close();
		// If/else statements used to figure out how many natural roots a given equation
		// has, if any. Using known mathematical conditions to figure out the number of
		// roots and then calculating them.
		if (b2 - 4 * a * c < 0)
			System.out.println("This equation has no real roots.");
		else {
			if (a == 0) {
				x = (-c) / b;
				System.out.println("This equation has one real root: " + killdecimal.format(x));
			} else {
				x = (-b + Math.sqrt(b2 - 4 * a * c)) / (2 * a);
				x2 = (-b - Math.sqrt(b2 - 4 * a * c)) / (2 * a);
				System.out.println("The is equation has 2 real roots. " + x + " and " + x2);
			}
		}
	}

}
