
/**
 * October 15, 2017 11:00 AM
 * @author hmann11
 * This program calculates the cumulative tax for a given annual income.
 */
import java.text.NumberFormat;
import java.util.Scanner;

public class Exercise2 {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		NumberFormat dollar = NumberFormat.getCurrencyInstance();
		NumberFormat percent = NumberFormat.getPercentInstance();
		percent.setMinimumFractionDigits(2);
		// Using x and its variants to store the individual tax for every tax bracket.
		// Using p and its variants to store the percentage of tax for every tax
		// bracket.Paylimit store the tax of the applicable uppermost tax bracket for a
		// given amount.
		double x = 0;
		double x1 = 0;
		double x2 = 0;
		double x3 = 0;
		double x4 = 0;
		double total = 0;
		double paylimit = 0;
		double p1 = 0.0506;
		double p2 = 0.0770;
		double p3 = 0.1050;
		double p4 = 0.1229;
		double p5 = 0.1470;
		System.out.print("Please enter your annual income greater than 0: ");
		double pay = input.nextInt();
		// Checking the input to see if it is more that 0. If the number entered is
		// positive then using if/else statements to determine what tax bracket the pay
		// falls in. For every tax bracket the program prints out all the percentages of
		// taxes but only uses the applicable tax percentage to calculate the total tax.
		// Every else statement after the first assumes that the last tax bracket is
		// constant (for example if a amount doesn't fulfill the first statement, that
		// means that the amount is more that $ 38210 and that the tax percentage can be
		// directly applied to it in the next statement and then the next bracket can be
		// calculated by subtracting $38210 from the given amount so that the remaining
		// amount can be put in the next tax bracket and the correct tax percentage can
		// be applied to it) and only calculates the upper
		// most tax bracket for the given amount.
		if (pay < 0)
			System.out.println("Invalid income , amount must be positive.");
		else {
			if (pay <= 38210) {
				x = pay * p1;
				total = x + x1 + x2 + x3 + x4;
				System.out.println(dollar.format(pay) + " taxed at " + percent.format(p1) + ": " + dollar.format(x)
						+ "\n" + dollar.format(0) + " taxed at " + percent.format(p2) + ": " + dollar.format(x1) + "\n"
						+ dollar.format(0) + " taxed at " + percent.format(p3) + ": " + dollar.format(x2) + "\n"
						+ dollar.format(0) + " taxed at " + percent.format(p4) + ": " + dollar.format(x3) + "\n"
						+ dollar.format(0) + " taxed at " + percent.format(p5) + ": " + dollar.format(x4) + "\n"
						+ "Your total income tax is: " + dollar.format(total));
			} else {
				if (pay > 38210 && pay < 76421) {
					paylimit = pay - 38210.01;
					x = 38210 * p1;
					x1 = paylimit * p2;
					total = x + x1 + x2 + x3 + x4;
					System.out.println(dollar.format(38210.00) + " taxed at " + percent.format(p1) + ": "
							+ dollar.format(x) + "\n" + dollar.format(paylimit) + " taxed at " + percent.format(p2)
							+ ": " + dollar.format(x1) + "\n" + dollar.format(0) + " taxed at " + percent.format(p3)
							+ ": " + dollar.format(x2) + "\n" + dollar.format(0) + " taxed at " + percent.format(p4)
							+ ": " + dollar.format(x3) + "\n" + dollar.format(0) + " taxed at " + percent.format(p5)
							+ ": " + dollar.format(x4) + "\n" + "Your total income tax is: " + dollar.format(total));
				} else {
					if (pay > 76421 && pay < 87741) {
						paylimit = pay - 76421;
						x = 38210 * p1;
						x1 = (76421 - 38210.01) * p2;
						x2 = paylimit * p3;
						total = x + x1 + x2 + x3 + x4;
						System.out.println(dollar.format(38210.00) + " taxed at " + percent.format(p1) + ": "
								+ dollar.format(x) + "\n" + dollar.format(38211.00) + " taxed at " + percent.format(p2)
								+ ": " + dollar.format(x1) + "\n" + dollar.format(paylimit) + " taxed at "
								+ percent.format(p3) + ": " + dollar.format(x2) + "\n" + dollar.format(0) + " taxed at "
								+ percent.format(p4) + ": " + dollar.format(x3) + "\n" + dollar.format(0) + " taxed at "
								+ percent.format(p5) + ": " + dollar.format(x4) + "\n" + "Your total income tax is: "
								+ dollar.format(total));
					} else {
						if (pay > 87741 && pay < 106543) {
							paylimit = pay - 87741;
							x = 38210 * p1;
							x1 = (76421 - 38210) * p2;
							x2 = (87741 - 76421) * p3;
							x3 = paylimit * p4;
							total = x + x1 + x2 + x3 + x4;
							System.out.println(dollar.format(38210.00) + " taxed at " + percent.format(p1) + ": "
									+ dollar.format(x) + "\n" + dollar.format(38211.00) + " taxed at "
									+ percent.format(p2) + ": " + dollar.format(x1) + "\n" + dollar.format(11320.00)
									+ " taxed at " + percent.format(p3) + ": " + dollar.format(x2) + "\n"
									+ dollar.format(paylimit) + " taxed at " + percent.format(p4) + ": "
									+ dollar.format(x3) + "\n" + dollar.format(0) + " taxed at " + percent.format(p5)
									+ ": " + dollar.format(x4) + "\n" + "Your total income tax is: "
									+ dollar.format(total));
						} else {
							paylimit = pay - 106543;
							x = 38210 * p1;
							x1 = (76421 - 38210.01) * p2;
							x2 = (87741 - 76421) * p3;
							x3 = (106543 - 87741) * p4;
							x4 = paylimit * p5;
							total = x + x1 + x2 + x3 + x4;
							System.out.println(dollar.format(38210.00) + " taxed at " + percent.format(p1) + ": "
									+ dollar.format(x) + "\n" + dollar.format(38211.00) + " taxed at "
									+ percent.format(p2) + ": " + dollar.format(x1) + "\n" + dollar.format(11320.00)
									+ " taxed at " + percent.format(p3) + ": " + dollar.format(x2) + "\n"
									+ dollar.format(18802.00) + " taxed at " + percent.format(p4) + ": "
									+ dollar.format(x3) + "\n" + dollar.format(paylimit) + " taxed at "
									+ percent.format(p5) + ": " + dollar.format(x4) + "\n"
									+ "Your total income tax is: " + dollar.format(total));
						}
					}
				}
			}
		}

		input.close();
	}
}
