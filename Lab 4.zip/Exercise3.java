
/**
 * October 15,2017 2:00 PM
 * @author hmann11
 * This program takes in a certain amount of integers from the user and prints of the average of the numbers.
 */
import java.util.Scanner;

public class Exercise3 {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		float num = 0;
		float total = 0;
		float count = 0;
		System.out.println("Please enter some number (a negative number to stop):");
		num = input.nextFloat();
		// Creating an if statement to check if the first number provided is a positive
		// number. The do statement is going to keep taking in input until the user
		// enters a negative integer.Also setting up a counter to use to calculate the
		// average.
		if (num > 0) {
			do {
				total += num;
				num = input.nextFloat();
				count++;
			} while (num > 0);
			// Dividing the total from the number of numbers entered to get the average and
			// printing out the average.
			double average = total / count;
			System.out.println("Average is: " + average);
		} else {
			System.out.println("No positive numbers provided.");
		}

		input.close();
	}

}
