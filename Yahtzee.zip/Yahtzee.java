
/**
 * November 20th,2017 7:36 AM
 * @author hmann11
 * This program emulates a game of Yahtzee.
 */
import java.util.Arrays;
import java.util.Scanner;

public class Yahtzee {
	static Scanner input = new Scanner(System.in);

	/**
	 * This is the main method that asks the user for a input when necessary. The
	 * dice array stores the dice roll for each of the turn and the scoreCard array
	 * stores the total score for every turn. Finally the correction array acts as a
	 * record of which method the user has already used.
	 */
	public static void main(String[] args) {
		int[] dice = new int[5];
		int[] scoreCard = new int[13];
		int[] correction = new int[14];// Adding a 13th integer to in case there are no suitable categories for the
										// user.

		// The for loop repeats 13 times in order to complete a game.
		for (int i = 1; i < 14; i++) {
			System.out.println("Turn " + i);
			rollDice(dice);
			reRoll(dice);
			System.out.println(
					"Which item would you like to score on your score card?(the number 1 in the brackets adjacent to the choice represent if you have already used the category before)"
							+ "\n" + "0=aces(" + correction[0] + ")" + "\t" + "1=twos(" + correction[1] + ")" + "\t"
							+ "2=threes(" + correction[2] + ")  " + "3=fours(" + correction[3] + ")   " + "4=fives("
							+ correction[4] + ")   " + "\t" + "5=sixes(" + correction[5] + ")   " + "\n"
							+ "6=three of a kind(" + correction[6] + ")" + "\t" + "7=four of a kind(" + correction[7]
							+ ")" + "\t" + "8=full house(" + correction[8] + ")" + "\n" + "9=small straight("
							+ correction[9] + ")" + "\t" + "10=large stright(" + correction[10] + ")" + "\t"
							+ "11=Yahtzee(" + correction[11] + ")" + "\t" + "12=chance(" + correction[12] + ")" + "\n"
							+ "Enter 13 if no choice is suitable");
			int category = input.nextInt();

			// While loop to check if the dice combination is compatible with category 11
			// i.e. if all 5 dice are the same.
			while (checkIdentical(dice) != true && category == 11) {
				System.out.println("That category does not apply to the dice sequence.");
				category = input.nextInt();

			}

			scoreDice(scoreCard, dice, category, correction);
		}
		System.out.println(Arrays.toString(scoreCard));
		System.out.println("Total: " + sumAllDice(scoreCard));
	}

	/**
	 * Method to check if all the die in a sequence are the same
	 * 
	 * @param dice
	 *            is the array that needs to be check.
	 * @return true if all the dice are the same and false if otherwise.
	 */
	private static boolean checkIdentical(int[] dice) {
		boolean a = false;
		if (dice[0] == dice[1] && dice[1] == dice[2] && dice[2] == dice[3] && dice[3] == dice[4]) {
			a = true;
		}
		return a;

	}

	/**
	 * Roll the dice using a random generator to fill in every slot of the array.
	 * 
	 * @param dice
	 *            is the empty array to be filled.
	 */
	public static void rollDice(int[] dice) {
		for (int i = 0; i < dice.length; i++) {
			dice[i] = (int) (Math.random() * 6 + 1);
		}
		System.out.println(Arrays.toString(dice));
	}

	/**
	 * This method takes the dice array generated from the previous method and asks
	 * the user the number of dice he/she would like to roll again for a suitable
	 * outcome and then asks which die the user wants to roll.
	 *
	 * @param dice
	 */
	public static void reRoll(int[] dice) {
		for (int i = 1; i < 4; i++) {
			System.out.println("Reroll attempt:" + i + ". How many dice would you like to reroll?");
			int num = input.nextInt();
			// if the number enter is zero then the program assumes the user doesn't want to
			// change any entries. If a non zero number is entered then a for loop is used.
			if (num != 0) {
				System.out.println("Indicate the dice number(s) 0-4 you would like to reroll:");
				// Num is used as the upper limit for the loop in order to run it as many times
				// as the number of dice the user wants to change. The integer p denotes the
				// index of the dice to be changed.
				for (int j = 0; j < num; j++) {
					int p = input.nextInt();
					dice[p] = (int) (Math.random() * 6 + 1);
				}
				System.out.println(Arrays.toString(dice));
			}
		}

	}

	/**
	 * This method all the integer in a array.
	 * 
	 * @param dice
	 *            the array to be added
	 * @return sum of all values in a array
	 */
	public static int sumAllDice(int[] dice) {
		int sum = 0;
		// for each loop to iterate through the array and add all the numbers.
		for (int i : dice) {
			sum += i;
		}
		return sum;
	}

	/**
	 * This method adds all the slots in array of a given integer value
	 * 
	 * @param dice
	 *            the array from which all the entities of the given integer are to
	 *            added.
	 * @param faceVal
	 *            the integer value to be added.
	 * @return sum of all the values added.
	 */
	public static int sumOfDice(int[] dice, int faceVal) {
		int sum = 0;
		for (int i = 0; i < dice.length; i++) {
			if (dice[i] == faceVal) {
				sum += dice[i];
			}
		}
		return sum;
	}

	/**
	 * This program accepts a dice array and the category a user would like to use
	 * with it and then stores the final score in a separate array.
	 * 
	 * @param scorecard
	 *            is the array used to store the final score for a turn
	 * @param dice
	 *            is the dice array used to generate the score for a turn
	 * @param category
	 *            is an int to represent the type of sequence the user would like to
	 *            use to account for the score for example large straight, three of
	 *            one etc.
	 * @param correction
	 *            an array to account for the choices the user has already used.
	 */
	public static void scoreDice(int[] scorecard, int[] dice, int category, int[] correction) {
		// while loop to take the correct input i.e. a input representing a choice that
		// has not been previously used.
		while (correction[category] != 0) {
			System.out.println("Please enter a valid choice i.e. a choice that has not been used before.");
			category = input.nextInt();
		}
		// switch used to provide every every choice with its correct response. Adding
		// to a specific slot in the correction array to account for the choices the
		// user has already used. The default case is used to provide an escape in case
		// the user doesnt want to use any of the choice and does not affect the final
		// score.
		switch (category) {
		case 0:

			scorecard[0] = sumOfDice(dice, 1);
			correction[0]++;

			break;
		case 1:

			scorecard[1] = sumOfDice(dice, 2);
			correction[1]++;

			break;
		case 2:

			scorecard[2] = sumOfDice(dice, 3);
			correction[2]++;

			break;
		case 3:

			scorecard[3] = sumOfDice(dice, 4);
			correction[3]++;

			break;
		case 4:

			scorecard[4] = sumOfDice(dice, 5);
			correction[4]++;

			break;
		case 5:

			scorecard[5] = sumOfDice(dice, 6);
			correction[5]++;

			break;
		case 6:

			scorecard[6] = sumAllDice(dice);
			correction[6]++;

			break;
		case 7:

			scorecard[7] = sumAllDice(dice);
			correction[7]++;

			break;
		case 8:

			scorecard[8] = 25;
			correction[8]++;

			break;
		case 9:

			scorecard[9] = 30;
			correction[9]++;

			break;
		case 10:

			scorecard[10] = 40;
			correction[10]++;

			break;
		case 11:

			scorecard[11] = 50;
			correction[11]++;

			break;
		case 12:

			scorecard[12] = sumAllDice(dice);
			correction[12]++;

			break;
		default:
			scorecard[12] += 0;

		}

	}
}
